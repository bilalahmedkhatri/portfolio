# need result in this format [0,1,2,3]

