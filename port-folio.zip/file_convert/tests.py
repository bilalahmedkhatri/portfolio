import os
from django.test import TestCase

# Create your tests here.

print(dir(os.getcwd()))